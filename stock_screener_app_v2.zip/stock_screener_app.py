
import yfinance as yf
import pandas as pd
import ta
import streamlit as st

st.title("📈 Enhanced Stock Screener (EMA + RSI + MACD + VWAP + Filters)")

tickers = st.text_area("Enter Ticker Symbols (comma-separated)", "AAPL, SPY, TSLA, MSFT").split(',')

# Filters
st.sidebar.header("🔎 Filter Settings")
min_price = st.sidebar.number_input("Min Price", value=5.0)
max_price = st.sidebar.number_input("Max Price", value=500.0)
min_volume = st.sidebar.number_input("Min Avg Volume", value=1_000_000)
rsi_range = st.sidebar.slider("RSI Range", 0, 100, (50, 70))

results = []

for ticker in [t.strip().upper() for t in tickers]:
    try:
        data = yf.download(ticker, period='5d', interval='15m')
        if data.empty:
            continue

        data['EMA9'] = ta.trend.ema_indicator(data['Close'], window=9).ema_indicator()
        data['EMA21'] = ta.trend.ema_indicator(data['Close'], window=21).ema_indicator()
        data['EMA200'] = ta.trend.ema_indicator(data['Close'], window=200).ema_indicator()
        data['RSI'] = ta.momentum.rsi(data['Close'], window=14)
        macd = ta.trend.macd(data['Close'])
        data['MACD'] = macd.macd_diff()
        data['VWAP'] = (data['High'] + data['Low'] + data['Close']) / 3

        latest = data.iloc[-1]
        current_price = latest['Close']
        average_volume = data['Volume'].mean()
        rsi_val = latest['RSI']

        if (
            min_price <= current_price <= max_price and
            average_volume >= min_volume and
            rsi_range[0] < rsi_val < rsi_range[1] and
            latest['Close'] > latest['EMA200'] and
            latest['EMA9'] > latest['EMA21'] and
            latest['MACD'] > 0 and
            latest['Close'] > latest['VWAP']
        ):
            results.append({
                "Ticker": ticker,
                "Price": round(current_price, 2),
                "Avg Volume": int(average_volume),
                "RSI": round(rsi_val, 2)
            })

    except Exception as e:
        st.warning(f"Error with {ticker}: {e}")

if results:
    st.success("✅ Matching Stocks:")
    st.dataframe(pd.DataFrame(results))
else:
    st.error("No matching stocks found with current filters.")
